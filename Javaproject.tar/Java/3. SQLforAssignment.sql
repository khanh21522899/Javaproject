CREATE DATABASE USER_BIKESTORE

use USER_BIKESTORE

drop table Bike_Store_User

CREATE table Bike_Store_User(
	user_id int not null,
	username varchar(255),
	user_password varchar(255),
	canInsert bit,
	canUpdate bit,
	canDelete bit,
	primary key(user_id)
)

insert into Bike_Store_User (user_id, username, user_password, canInsert, canUpdate, canDelete) values (1,'sa','sa',1,1,1)
insert into Bike_Store_User (user_id, username, user_password, canInsert, canUpdate, canDelete) values (2,'GUEST','GUEST',1,0,0)

select * from Bike_Store_User


/*Create login and role for guest*/

create login GUEST with password = 'GUEST' 
use BIKESTORE
create user GUEST for login GUEST
create role STORE_EMPLOYEE

GRANT select, insert to STORE_EMPLOYEE
Grant alter to STORE_EMPLOYEE

ALTER ROLE STORE_EMPLOYEE
ADD MEMBER GUEST



